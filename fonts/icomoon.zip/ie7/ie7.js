/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon_icon_long-arrow': '&#xe90d;',
		'icon_icon_points': '&#xe90b;',
		'icon_icon_cup': '&#xe90a;',
		'icon_icon_shield': '&#xe908;',
		'icon_icon_star': '&#xe909;',
		'icon_icon_mail': '&#xe907;',
		'icon_icon_dislike': '&#xe905;',
		'icon_icon_like': '&#xe906;',
		'icon_icon_prize': '&#xe902;',
		'icon_icon_share': '&#xe904;',
		'icon_icon_twitter': '&#xe903;',
		'icon_icon_search': '&#xe901;',
		'icon_icon_ok': '&#xe90c;',
		'icon_icon_blocks': '&#xe900;',
		'icon_icon_light': '&#xea0d;',
		'icon_icon_lock': '&#xea0e;',
		'icon_icon_watch': '&#xea0f;',
		'icon_icon_comment': '&#xea0b;',
		'icon_icon_view': '&#xea0c;',
		'icon_icon_quot': '&#xea0a;',
		'icon_icon_check': '&#xea09;',
		'icon_icon_arrow': '&#xea07;',
		'icon_icon_fb': '&#xea01;',
		'icon_icon_instagram': '&#xea02;',
		'icon_icon_vk': '&#xea03;',
		'icon_icon_burn': '&#xea04;',
		'icon_icon_gift': '&#xea05;',
		'icon_icon_medal': '&#xea06;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon_[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
